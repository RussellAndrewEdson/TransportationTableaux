/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef ANCILLARY_HPP
#define ANCILLARY_HPP

#include <vector>
#include <algorithm>
#include <utility>
#include <numeric>

namespace transportation_tableaux {
    /**
     * IntPair is given as a shorthand for the STL pair of integers.
     */
    using IntPair = std::pair<int, int>;

    /**
     * IntMatrix is given as a shorthand for a vector of integer vectors
     * from the STL. Using a vector of vectors for our matrix definition
     * allows us to use a more natural-looking [i][j] subscript for the
     * element in the "i-th row" and the "j-th column".
     */
    using IntMatrix = std::vector< std::vector<int> >;

    /**
     * Finds all pairs that are adjacent to the given pair from the
     * vector of candidates. In terms of the transportation tableau, we
     * consider two pairs adjacent to one another if we can start at one
     * pair and reach the other by going in a straight line (up, down,
     * left or right) in the grid, without bumping into a different
     * pair first.
     *
     * @param pair The pair that we want to check for adjacent pairs.
     * @param candidates The vector of pairs to be considered for adjacency.
     * @return A vector of pairs that are adjacent to the specified pair.
     */
    std::vector<IntPair> find_adjacent_pairs(const IntPair& pair,
            const std::vector<IntPair>& candidates);

    /**
     * Find those pairs that exist on the cycle in the tableau when the star
     * pair is considered along with the existing basic pairs.
     *
     * For our case with the transportation tableau, there should only ever
     * exist a single minimal cycle with no redundant pairs (ie. we only
     * include vertex pairs which determine the shape of the cycle). We can
     * isolate this cycle by first repeatedly "pruning" away those pairs that
     * are only adjacent to a single other pair, and then once a cycle has
     * been reached, we test the necessity of each of the pairs in the cycle
     * to determine any that can be safely removed.
     *
     * @param basic_pairs The basic pairs for the current tableau.
     * @return A vector of those integer pairs that constitute the cycle.
     */
    std::vector<IntPair> find_cycle(const std::vector<IntPair>& basic_pairs);

    /**
     * Removes a specified pair from the given vector. If the pair does not
     * exist in the vector, this function does nothing. If the pair exists
     * multiple times in the vector, this function will only remove the
     * first occurrence.
     *
     * @param pair_to_remove The pair to be removed from the vector.
     * @param pairs The vector of integer pairs to remove from.
     */
    void remove_pair(IntPair pair_to_remove, std::vector<IntPair>& pairs);

    /**
     * Returns the sum of all of the integer elements in the given vector.
     *
     * (This function simply uses the STL facilities for accumulation of
     * element values from the <numeric> library -- it is provided to save
     * having to write that whole long line out every time.)
     *
     * @param elements The integer vector to sum up.
     * @return The sum of all of the integers in the vector.
     */
    int sum_elements(const std::vector<int>& elements);

}

#endif

