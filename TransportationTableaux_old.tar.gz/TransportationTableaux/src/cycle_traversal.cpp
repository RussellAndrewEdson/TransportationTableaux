/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "cycle_traversal.hpp"

namespace transportation_tableaux {

    CycleTraversal::CycleTraversal(IntPair star_pair,
            std::vector<IntPair> cycle_pairs) : star_pair(star_pair) {

        /* We sort the cycle_pairs in traversal order. */
        this->traversal_order.push_back(star_pair);
        remove_pair(star_pair, cycle_pairs);

        while ( !cycle_pairs.empty() ) {
            IntPair current_pair = this->traversal_order.back();
            std::vector<IntPair> adjacent =
                find_adjacent_pairs(current_pair, cycle_pairs);

            /* Here we arbitrarily pick the direction to traverse in.
             * We always go with whatever the first pair is, and note
             * that we only have to make this choice for the first pair;
             * after that, there is only ever one pair in the return vector.
             * (Alternatively, if no adjacent pairs were found, then
             * something went wrong, and we exit with only the star pair.)
             */
            if ( !adjacent.empty() ) {
                this->traversal_order.push_back(adjacent.front());
                remove_pair(adjacent.front(), cycle_pairs);
            }
            else {
                this->traversal_order.clear();
                this->traversal_order.push_back(star_pair);
                break;
            }
        }

        /* Then we move along the cycle, alternating between labelling
         * the pairs with a "plus" or a "minus". The star pair is always
         * labelled with a "plus".
         */
        for (unsigned int i = 0; i < this->traversal_order.size(); i++) {
            if (i % 2 == 0) {
                this->plus_pairs.push_back(this->traversal_order[i]);
            }
            else {
                this->minus_pairs.push_back(this->traversal_order[i]);
            }
        }
    }

    CycleTraversal::~CycleTraversal() {
        /* Nothing is stored on the freestore, so this destructor
         * doesn't need to do anything.
         */
    }

    std::vector<IntPair>::iterator CycleTraversal::begin() {
        return traversal_order.begin();
    }

    std::vector<IntPair>::const_iterator CycleTraversal::begin() const {
        return traversal_order.begin();
    }

    std::vector<IntPair>::iterator CycleTraversal::end() {
        return traversal_order.end();
    }

    std::vector<IntPair>::const_iterator CycleTraversal::end() const {
        return traversal_order.end();
    }

    std::vector<IntPair> CycleTraversal::get_minus_pairs() const {
        return minus_pairs;
    }

    std::vector<IntPair> CycleTraversal::get_plus_pairs() const {
        return plus_pairs;
    }

    IntPair CycleTraversal::get_star_pair() const {
        return star_pair;
    }

}

