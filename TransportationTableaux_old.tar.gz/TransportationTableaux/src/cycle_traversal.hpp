/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef CYCLE_TRAVERSAL_HPP
#define CYCLE_TRAVERSAL_HPP

#include <vector>
#include <utility>

#include "ancillary.hpp"

namespace transportation_tableaux {

    /**
     * A class to represent a cycle and its traversal order in the
     * transportation tableau.
     *
     * To find the solution to a balanced transportation problem, we
     * generate successively more optimal tableau by adding a "star pair"
     * to fix up a deficit allocation, and then look for a cycle formed
     * by the basic pairs and the added star pair. By adjusting the
     * allocations around this cycle accordingly, we arrive at a new
     * distribution of the supply which has a smaller (or equal) cost.
     *
     * Class usage example:
     * <pre>
     *     // Set up a cycle from a star pair and a small list of pairs
     *     CycleTraversal cycle( {1,0}, { {0,0}, {0,1}, {1,0}, {1,1} } );
     *
     *     // After the cycle traversal object has been instantiated, all of
     *     // the work to find the traversal order and the plus/minus pairs
     *     // will have already been done. We can access these easily:
     *     cycle.get_minus_pairs();                 // { {1,1}, {0,0} }
     *     cycle.get_plus_pairs();                  // { {1,0}, {0,1} }
     *     cycle.get_star_pair();                   // {1,0}
     *
     *     // The class also provides begin() and end() iterators to allow
     *     // for easy traversal of the cycle during a loop:
     *     for (IntPair& pair : cycle) {
     *         std::cout << "{ " << pair.first;     // {1,0}
     *         std::cout << ", " << pair.second;    // {1,1}
     *         std::cout << " }" << std::endl;      // {0,1}
     *     }                                        // {0,0}
     * </pre>
     *
     * @author Russell Edson, <russell.andrew.edson@gmail.com>
     * @version 1.0
     * @date 24/06/2014
     */
    class CycleTraversal {
    private:
        /**
         * The pairs on the cycle that have been labelled with a minus.
         * These pairs should have their allocations adjusted downward
         * for the next tableau.
         */
        std::vector<IntPair> minus_pairs;

        /**
         * The pairs on the cycle that have been labelled with a plus.
         * The allocations for these pairs should be adjusted upward
         * by the algorithm for the next tableau.
         */
        std::vector<IntPair> plus_pairs;

        /**
         * The star pair that was originally added to the basic pairs
         * to create the cycle. This star pair will always have its
         * allocation adjusted upward for the next tableau as part of
         * the optimisation process.
         */
        IntPair star_pair;

        /**
         * The traversal order for the cycle. We start with the star
         * pair and go around the cycle, alternating between plus-
         * and minus-labelled pairs.
         *
         * (This ordering will also dictate the exact shape of the cycle, and
         * so we can use it to draw the cycle graphically if desired.)
         */
        std::vector<IntPair> traversal_order;

    public:
        /**
         * Constructor for the CycleTraversal object. Creates a new cycle
         * using the given star pair and the pairs that exist on the
         * minimal cycle (the minimal cycle can be found by calling the
         * find_cycle() method in the ancillary header.)
         *
         * This constructor orders the cycle pairs along a traversal path
         * (starting with the star pair), and alternates between plus and
         * minus labels for each of the pairs in turn. These labels dictate
         * whether that pair should have its allocations increased (plus) or
         * decreased (minus) to reach a more optimal tableau. Note that the
         * star pair will always have its allocations increased.
         *
         * Note: If no cycle can be constructed from the input pairs (or
         * something goes wrong during the construction), then only the
         * star pair will exist on this CycleTraversal.)
         *
         * @param star_pair The star pair for the current tableau.
         * @param cycle_pairs The pairs that exist on the minimal cycle.
         */
        CycleTraversal(IntPair star_pair, std::vector<IntPair> cycle_pairs);

        /**
         * Destructor for the CycleTraversal object. The default is fine to
         * be used here (we don't allocate anything on the freestore).
         */
        ~CycleTraversal();

        /**
         * Returns an iterator to the beginning of the cycle traversal path.
         * Note that this iterator will always point to the star pair.
         *
         * @return An iterator to the beginning of the traversal path.
         */
        std::vector<IntPair>::iterator begin();

        /**
         * Returns a constant iterator to the beginning of the cycle
         * traversal path. Note that this iterator will always point to
         * the star pair.
         *
         * @return A constant iterator to the beginning of the traversal path.
         */
        std::vector<IntPair>::const_iterator begin() const;

        /**
         * Returns an iterator to the end of the cycle traversal path
         * (ie. one place past the last pair, as per the STL convention).
         *
         * @return An iterator to the end of the traversal path.
         */
        std::vector<IntPair>::iterator end();

        /**
         * Returns a constant iterator to the end of the cycle traversal
         * path (ie. one place past the last pair, as per the STL convention).
         *
         * @return A constant iterator to the end of the traversal path.
         */
        std::vector<IntPair>::const_iterator end() const;

        /**
         * Returns a vector containing those pairs on the cycle that have
         * been labelled with a minus (-). For the next tableau, these minus
         * pairs should have their allocations decreased.
         *
         * @return The pairs that have been labelled with a minus.
         */
        std::vector<IntPair> get_minus_pairs() const;

        /**
         * Returns a vector containing those pairs on the cycle that have
         * been labelled with a plus (+). These are the pairs that should
         * have their allocations increased for the next tableau.
         *
         * @return The pairs that have been labelled with a plus.
         */
        std::vector<IntPair> get_plus_pairs() const;

        /**
         * Returns the star pair that marks the start of the cycle traversal
         * path.
         *
         * @return The star pair for the tableau cycle.
         */
        IntPair get_star_pair() const;

    };

}

#endif

