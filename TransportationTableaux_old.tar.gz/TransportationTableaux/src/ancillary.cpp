/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "ancillary.hpp"

namespace transportation_tableaux {

    std::vector<IntPair> find_adjacent_pairs(const IntPair& pair,
            const std::vector<IntPair>& candidates) {

        /* We first find all pairs that are up, down, left or right from the
         * given pair.
         */
        enum Direction { LEFT, RIGHT, UP, DOWN };
        std::vector< std::vector<IntPair> > directions(4);

        for (const IntPair& other : candidates) {
            if (other.first == pair.first) {
                if (other.second < pair.second) {
                    directions[LEFT].push_back(other);
                }
                /* Note here that we don't even care about the equality case;
                 * we don't consider a pair to be adjacent to itself.
                 */
                else if (other.second > pair.second) {
                    directions[RIGHT].push_back(other);
                }
            }
            if (other.second == pair.second) {
                if (other.first < pair.first) {
                    directions[UP].push_back(other);
                }
                /* Once again, we don't consider the equality case here. */
                else if (other.first > pair.first) {
                    directions[DOWN].push_back(other);
                }
            }
        }

        /* Now we construct the adjacent pair vector by choosing the closest
         * pair at each point (which might be "none" in some cases.)
         */
        std::vector<IntPair> adjacent;
        for (int dir = LEFT; dir <= DOWN; dir++) {
            std::vector<IntPair>& pairs = directions[dir];

            if ( !pairs.empty() ) {
                /* For the pairs to the left and above, the closest will
                 * always be the largest pair in the direction set.
                 */
                if ( (dir == LEFT) || (dir == UP) ) {
                    adjacent.push_back(
                            *std::max_element(pairs.begin(), pairs.end()));
                }

                /* For the pairs to the right and below, the closest will
                 * always be the smallest pair in the direction set.
                 */
                else if ( (dir == RIGHT) || (dir == DOWN) ) {
                    adjacent.push_back(
                            *std::min_element(pairs.begin(), pairs.end()));
                }
            }
        }

        return adjacent;
    }

    std::vector<IntPair> find_cycle(const std::vector<IntPair>& basic_pairs) {
        /* First, we define the function that will prune down a given set of
         * pairs to the cycle for us (and if no cycle exists, we prune it
         * down to nothing -- we use this fact to check for redundant pairs
         * that don't add anything to the cycle structure.)
         */
        auto prune_to_cycle = [] (std::vector<IntPair>& pairs) {
            std::vector<IntPair> cycle = pairs;
            while ( !cycle.empty() ) {
                bool pair_removed_from_cycle = false;
                for (IntPair& pair : cycle) {
                    /* We find the adjacent pairs to the current pair; if
                     * there is less than 2, then our pair is not a part of
                     * the cycle and can be removed.
                     */
                    std::vector<IntPair> adjacent_pairs
                            = find_adjacent_pairs(pair, cycle);
                    if (adjacent_pairs.size() < 2) {
                        remove_pair(pair, cycle);
                        pair_removed_from_cycle = true;
                        break;
                    }
                }

                /* If we never removed a pair from the cycle this round, then
                 * we've arrived at the cycle.
                 */
                if (pair_removed_from_cycle == false) {
                    break;
                }
            }

            /* At this point we're done: we either have the cycle, or nothing.
             */
            return cycle;
        };

        /* With our pruning function, we now find the minimal cycle. Note that
         * we use the fact that our function returns an empty vector to
         * check for whether a given pair is strictly necessary.
         */
        std::vector<IntPair> cycle = basic_pairs;
        cycle = prune_to_cycle(cycle);

        if ( !cycle.empty() ) {
            /* We make a copy of the cycle here and remove the redundant pairs
             * from it. This saves us having to worry about the removal of
             * the pair affecting the loop. This should be fine, as for our
             * cycles a pair is redundant absolutely: it isn't dependent on
             * whether other redundant pairs have been removed first.
             */
            std::vector<IntPair> minimal_cycle = cycle;

            for (IntPair& pair : cycle) {
                std::vector<IntPair> test_cycle = cycle;
                remove_pair(pair, test_cycle);
                test_cycle = prune_to_cycle(test_cycle);

                if ( !test_cycle.empty() ) {
                    /* In this case we can safely remove the considered pair
                     * from the cycle without affecting the structure.
                     */
                    remove_pair(pair, minimal_cycle);
                }
            }

            cycle = minimal_cycle;
        }

        return cycle;
    }

    void remove_pair(IntPair pair_to_remove, std::vector<IntPair>& pairs) {
        std::vector<IntPair>::iterator position =
            std::find(pairs.begin(), pairs.end(), pair_to_remove);

        if (position != pairs.end()) {
            pairs.erase(position);
        }
    }

    int sum_elements(const std::vector<int>& elements) {
        return std::accumulate(elements.begin(), elements.end(), 0);
    }

}

