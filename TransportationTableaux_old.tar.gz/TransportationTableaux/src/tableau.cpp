/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "tableau.hpp"
#include <iostream>

namespace transportation_tableaux {

    Tableau::Tableau(IntMatrix link_flow_costs, std::vector<int> supplies,
            std::vector<int> demands) : demands(demands),
            link_flow_costs(link_flow_costs), supplies(supplies) {

        /* Set allocations to zero initially. */
        allocations.resize(link_flow_costs.size());
        for (unsigned int i = 0; i < allocations.size(); i++) {
            allocations[i].resize(link_flow_costs[i].size());
        }

        /* No cycle exists in the tableau to start with. */
        cycle.reset();

        /* No star pair exists in the tableau to start with either. */
        star_pair.reset();

        /* The ui and vj values are initialised to zero. */
        ui_values.resize(supplies.size());
        vj_values.resize(demands.size());
    }

    Tableau::~Tableau() {
        /* We don't allocate anything on the freestore, so the destructor
         * doesn't need to free up any memory here.
         */
    }

    void Tableau::adjust_allocations() {
        /* First, we find the minus-labelled pair on the cycle with the
         * smallest allocation in the current tableau.
         */
        std::vector<IntPair> minus_pairs = cycle->get_minus_pairs();
        std::vector<IntPair> plus_pairs = cycle->get_plus_pairs();
        
        //TODO: We can replace most of this code with a call to the
        // std::min_element() function with a suitable comparator.
        //auto pair_allocation = [this] (IntPair& pair) {
        //    return allocations[pair.first][pair.second];
        //};
        //
        //IntPair min_pair = minus_pairs[0];
        //int min_allocation = pair_allocation(min_pair);
        //for (unsigned int i = 1; i < minus_pairs.size(); i++) {
        //    IntPair current_pair = minus_pairs[i];
        //    int current_allocation = pair_allocation(current_pair);
        //
        //    if (current_allocation < min_allocation) {
        //        min_allocation = current_allocation;
        //        min_pair = current_pair;
        //    }
        //}

        IntPair min_pair = *(std::min_element(
                minus_pairs.begin(), minus_pairs.end(),
                [this] (const IntPair& p1, const IntPair& p2) -> bool {
                    return (allocations[p1.first][p1.second] < 
                            allocations[p2.first][p2.second]);
                }
        ));
        int min_allocation = allocations[min_pair.first][min_pair.second];

        /* We then adjust the allocations by adding the above minimum to
         * each of the plus-labelled pairs, and subtracting it from all
         * of the minus-labelled pairs.
         */
        for (const IntPair& pair : minus_pairs) {
            allocations[pair.first][pair.second] -= min_allocation;
        }
        for (const IntPair& pair : plus_pairs) {
            allocations[pair.first][pair.second] += min_allocation;
        }

        /* Finally, we update the basic pairs list by removing the minimum
         * allocation entry.
         */
        remove_pair(min_pair, basic_pairs);
    }

    void Tableau::determine_cycle() {
        std::vector<IntPair> cycle_pairs = find_cycle(basic_pairs);
        cycle.reset( new const CycleTraversal(*star_pair, cycle_pairs) );
    }

    void Tableau::determine_star_pair() {
        /* The star pair is determined by finding an (i,j) pair such
         * that the sum of the corresponding ui and vj values exceeds
         * the link-flow cost value.
         */
        for (unsigned int i = 0; i < link_flow_costs.size(); i++) {
            for (unsigned int j = 0; j < link_flow_costs[i].size(); j++) {
                if ( (ui_values[i] + vj_values[j]) > link_flow_costs[i][j] ) {
                    star_pair.reset( new const IntPair {i,j} );
                    basic_pairs.push_back(*star_pair);
                    return;
                }
            }
        }

        /* If we got here, then no star pair could be found. */
        star_pair.reset();
    }

    IntMatrix Tableau::get_allocations() const {
        return allocations;
    }

    std::vector<IntPair> Tableau::get_basic_pairs() const {
        return basic_pairs;
    }

    int Tableau::get_cost() const {
        /* We construct the cost by multiplying each of the allocations
         * by their corresponding link-flow cost.
         */
        int cost = 0;
        for (unsigned int i = 0; i < link_flow_costs.size(); i++) {
            for (unsigned int j = 0; j < link_flow_costs[i].size(); j++) {
                cost += link_flow_costs[i][j] * allocations[i][j];
            }
        }

        return cost;
    }

    const CycleTraversal Tableau::get_cycle() const {
        return *cycle;
    }

    std::vector<int> Tableau::get_demands() const {
        return demands;
    }

    IntMatrix Tableau::get_link_flow_costs() const {
        return link_flow_costs;
    }

    const IntPair Tableau::get_star_pair() const {
        return *star_pair;
    }

    std::vector<int> Tableau::get_supplies() const {
        return supplies;
    }

    std::vector<int> Tableau::get_ui_values() const {
        return ui_values;
    }

    std::vector<int> Tableau::get_vj_values() const {
        return vj_values;
    }

    bool Tableau::is_optimal() const {
        /* The optimal tableau has been reached if the sum of the ui and vj
         * values for all cells of the cost matrix is less than the
         * cost value.
         */
        for (unsigned int i = 0; i < ui_values.size(); i++) {
            for (unsigned int j = 0; j < vj_values.size(); j++) {
                if (ui_values[i] + vj_values[j] > link_flow_costs[i][j]) {
                    return false;
                }
            }
        }

        /* If we got here, then we've successfully verified all of the ui
         * and vj sums, and we have the optimal solution.
         */
        return true;
    }

    void Tableau::next_tableau() {
        /* We simply call the other methods in the proper order here. */
        determine_star_pair();
        determine_cycle();
        adjust_allocations();
        solve_ui_vj();
    }

    void Tableau::northwest_corner_rule() {
        /* We start in the North-West corner of the tableau. */
        unsigned int i = 0, j = 0;
        int can_supply = supplies[i];
        int can_demand = demands[j];

        while ((i < allocations.size()) && (j < allocations[i].size()) ) {
            if (can_supply < can_demand) {
                /* Allocate the rest of the supply. */
                allocations[i][j] = can_supply;
                can_demand -= can_supply;

                /* Update the basic pairs vector. */
                basic_pairs.push_back(IntPair {i,j});

                /* Move one cell down. */
                i++;
                if (i < allocations.size()) {
                    can_supply = supplies[i];
                }
            }
            else {
                /* Allocate the rest of the demand. */
                allocations[i][j] = can_demand;
                can_supply -= can_demand;

                /* Update the basic pairs vector. */
                basic_pairs.push_back(IntPair {i,j});

                /* Move over one cell to the right. */
                j++;
                if (j < allocations[i].size()) {
                    can_demand = demands[j];
                }
            }
        }

        /* Finally we solve for the initial ui and vj values. */
        solve_ui_vj();
    }

    void Tableau::solve_ui_vj() {
        /* We keep track of which ui and vj values have been changed. */
        std::vector<bool> ui_changed(ui_values.size(), false);
        std::vector<bool> vj_changed(vj_values.size(), false);
        std::vector<int> filled_ui_indices;
        std::vector<int> filled_vj_indices;

        auto set_ui =
            [this, &ui_changed, &filled_ui_indices] (int index, int val) {
                ui_values[index] = val;
                filled_ui_indices.push_back(index);
                ui_changed[index] = true;
            };

        auto set_vj =
            [this, &vj_changed, &filled_vj_indices] (int index, int val) {
                vj_values[index] = val;
                filled_vj_indices.push_back(index);
                vj_changed[index] = true;
            };

        /* Traditionally we set ui[0] = 0, and use this to determine the
         * rest of the ui and vj values.
         */
        set_ui(0, 0);

        /* We move around the grid, filling in the rest of the ui and vj
         * values based on the values already found.
         */
        while ( !filled_ui_indices.empty() || !filled_vj_indices.empty() ) {
            if (!filled_ui_indices.empty()) {
                /* For a filled in ui value, we scan across and see if we can
                 * fill in any new vj values using the basic pairs.
                 */
                int filled_index = filled_ui_indices.front();
                for (const IntPair& pair : basic_pairs) {
                    int i = pair.first, j = pair.second;
                    if ( (i == filled_index) && !vj_changed[j]) {
                        set_vj( j, (link_flow_costs[i][j] - ui_values[i]) );
                    }
                }
                filled_ui_indices.erase(filled_ui_indices.begin());
            }
            else if (!filled_vj_indices.empty()) {
                /* For a filled in vj value, we scan the grid and see if we
                 * can fill in any more ui values using the basic pairs.
                 */
                int filled_index = filled_vj_indices.front();
                for (const IntPair& pair : basic_pairs) {
                    int i = pair.first, j = pair.second;
                    if ((j == filled_index) && !ui_changed[i]) {
                        set_ui( i, (link_flow_costs[i][j] - vj_values[j]) );
                    }
                }
                filled_vj_indices.erase(filled_vj_indices.begin());
            }
        }
    }

}

