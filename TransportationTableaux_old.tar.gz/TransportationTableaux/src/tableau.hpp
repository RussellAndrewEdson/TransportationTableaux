/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef TABLEAU_HPP
#define TABLEAU_HPP

#include <vector>
#include <utility>
#include <memory>
#include <algorithm>

#include "ancillary.hpp"
#include "cycle_traversal.hpp"

namespace transportation_tableaux {

    /**
     * A class to represent the tableau used to solve a Balanced
     * Transportation Problem of Integer Linear Programming, as found in
     * the area of Operations Research.
     *
     * The class has its accessor methods and operations structured in such
     * a way as to allow the transportation problem to be solved in a
     * step-by-step manner for learning and demonstration purposes.
     *
     * Class usage example:
     * <pre>
     *     // Set up the Tableau object with the supplies, demands and 
     *     // link-flow cost for the Transportation Problem.
     *     std::vector<int> supply {9, 5, 2};
     *     std::vector<int> demand {8, 4, 4};
     *     IntMatrix link_flow { {3, 2, 3}, {3, 5, 1}, {4, 6, 3} };
     *     Tableau tab(link_flow, supply, demand);
     *
     *     // We always perform the North-West Corner Rule to start with.
     *     tab.northwest_corner_rule();
     *
     *     // We can check the initial allocations and associated cost:
     *     tab.get_allocations();           // { {8 1 0}, {0 3 2}, {0 0 2} }
     *     tab.get_cost();                  // 49
     *
     *     // We can get the list of basic pairs at any time.
     *     tab.get_basic_pairs();           // {{0,0} {0,1} {1,1} {1,2} {2,2}}
     *
     *     // Next we find the star pair to adjust the allocations with.
     *     tab.determine_star_pair();
     *     tab.get_star_pair();             // {1,0}
     *
     *     // With the star pair found, we can find the grid cycle:
     *     tab.determine_cycle();
     *     tab.get_cycle();                 // {{1,0} {1,1} {0,1} {0,0}}
     *
     *     // We then adjust the allocations according to that cycle.
     *     tab.adjust_allocations();
     *     tab.get_allocations();           // { {5 4 0}, {3 0 2}, {0 0 2} }
     *
     *     // The cost will be smaller (or equal) for this new allocation:
     *     tab.get_cost();                  // 40
     *
     *     // We solve the ui and vj equations for the new tableau
     *     // (these are the values for the Dual problem.)
     *     tab.solve_ui_vj();
     *     tab.get_ui_values();             // {0, 0, 2}
     *     tab.get_vj_values();             // {3, 2, 1}
     *
     *     // Finally, we check if we've reached the optimal allocation.
     *     tab.is_optimal();                // false
     *
     *     // We can solve the problem automatically by simply looping
     *     // until the optimal tableau has been reached.
     *     while ( !tab.is_optimal() ) {
     *         tab.next_tableau();
     *         // print intermediate tableau if desired.
     *     }
     *
     *     // At this point, we have the optimal allocation of supply to
     *     // demand, and the minimum possible cost of transportation.
     *     tab.get_allocations();           // { {5 4 0}, {1 0 4}, {2 0 0} }
     *     tab.get_cost();                  // 38
     * </pre>
     *
     * @author Russell Edson, <russell.andrew.edson@gmail.com>
     * @version 1.0
     * @date 10/07/2014
     */
    class Tableau {
    private:
        /**
         * The matrix holding the current supply-to-demand allocation
         * values for the tableau. The [i][j] value of this matrix is
         * the current amount of supply i that should be transported
         * to demand j.
         *
         * Note that all allocations will be set to zero before the
         * North-West Corner Rule has been performed (by calling the
         * northwest_corner_rule() method). After that, the allocations
         * are adjusted through the adjust_allocations() method once
         * a star pair and cycle have been found for the tableau.
         */
        IntMatrix allocations;

        /**
         * The basic pairs for the current tableau. These are, more or less,
         * those pairs which have non-trivial allocation values.
         *
         * This vector will not hold any basic pairs until the North-West
         * Corner Rule has been performed by invoking the
         * northwest_corner_rule() method!
         *
         * Note that at some points there will be a basic pair with a trivial
         * allocation. This is because we keep the same number of basic
         * pairs throughout the entire algorithm (after the number has been
         * determined with the North-West Corner Rule).
         */
        std::vector<IntPair> basic_pairs;

        /**
         * The cycle for the tableau, used to determine the adjustments in
         * allocation values that need to be made to introduce the "star pair"
         * into the basic pair set.
         *
         * Note that this object is not instantiated until the first
         * invocation of the determine_cycle() method, which should be
         * called after a star pair has been found in the newest tableau.
         *
         * The code to determine the plus/minus cycle pairs and the traversal
         * order has been refactored into this delegate object. All of it takes
         * place at object instantiation, so we can simply access the
         * specifics of the cycle freely after we've found it.
         */
        std::unique_ptr<const CycleTraversal> cycle;

        /**
         * The vector of demands for the transportation problem.
         *
         * The algorithm (and by extension, this Tableau object) assumes a
         * Balanced Transportation Problem, where the sum of the supply
         * equals the sum of the demand. You should make sure that this is
         * the case before constructing the Tableau.
         * (However, the algorithm can still be run on an unbalanced
         * problem, for "educational purposes".)
         */
        std::vector<int> demands;

        /**
         * The matrix of link-flow costs for the transportation problem.
         * The [i][j] value of this matrix is the integral cost of
         * transporting from supply i to demand j. The algorithm aims to
         * find the right allocation to minimize the total cost incurred
         * through such transportation.
         */
        IntMatrix link_flow_costs;

        /**
         * The "star pair" is the pair added to the recent tableau to
         * create a cycle with the basic pairs.
         *
         * In the algorithm, if a tableau is not optimal, then there will
         * be some (supply/demand) pair that can be reallocated for a more
         * optimal solution. This is the star pair, which can be found for
         * a tableau with the determine_star_pair() method.
         */
        std::unique_ptr<const IntPair> star_pair;

        /**
         * The vector of supplies for the transportation problem.
         *
         * The algorithm (and by extension, this Tableau object) assumes a
         * Balanced Transportation Problem, where the sum of the supply
         * equals the sum of the demand. You should make sure that this is
         * true before you construct the Tableau. For "educational purposes",
         * you can still attempt to use this Tableau on an unbalanced problem
         * however.
         */
        std::vector<int> supplies;

        /**
         * The vector of ui values for the Dual of the Transportation Problem.
         *
         * We determine if the tableau is optimal by simultaneously seeking a
         * feasible set of values for the ui and vj variables in the Dual
         * problem. These are found using the solve_ui_vj() method once an
         * adjustment to the allocations has been made.
         */
        std::vector<int> ui_values;

        /**
         * The vector of vj values for the Dual of the Transportation Problem.
         *
         * We determine if the tableau is optimal by simultaneously seeking a
         * feasible set of values for the ui and vj variables in the Dual
         * problem. These are found using the solve_ui_vj() method once an
         * adjustment to the allocations has been made.
         */
        std::vector<int> vj_values;

    public:
        /**
         * Constructor for the Tableau object. Sets up a new tableau for the
         * Balanced Transportation problem defined by the given supplies, 
         * demands and the associated link-flow cost matrix.
         *
         * @param link_flow_costs The link-flow costs for the problem.
         * @param supplies The vector of supplies.
         * @param demands The vector of demands.
         */
        Tableau(IntMatrix link_flow_costs, std::vector<int> supplies,
                std::vector<int> demands);

        /**
         * Destructor for the Tableau object. The default is fine here
         * (we use the STL memory facilities to control the lifetime for
         * the CycleTraversal and star_pair objects instead of pointers,
         * so we don't have to deallocate anything ourselves.)
         */
        ~Tableau();

        /**
         * Adjusts the supply-to-demand allocations based on the current
         * tableau cycle traversal, and updates the set of basic pairs to
         * reflect the change.
         *
         * This method should only be called after the cycle for the current
         * tableau has been found (by using the determine_cycle() method.)
         *
         * Technical note: We always remove the minus-labelled pair with the
         * minimum allocation from the set of basic pairs once the allocation
         * changes have been made, even though we could realistically remove
         * any pair that had a 0 allocation. This simply saves us having to
         * do any more work than necessary.
         */
        void adjust_allocations();

        /**
         * Finds the minimal cycle between the star pair and the basic pairs
         * in the current tableau.
         *
         * This method assumes that the star pair has already been determined
         * (we can find it with the determine_star_pair() method).
         */
        void determine_cycle();

        /**
         * Finds the "star pair" that will have its allocation increased for
         * the next tableau. This is determined by searching for the set of
         * ui and vj values in the current tableau that is preventing
         * dual-feasibility for the transportation problem.
         *
         * This method is the method that should be called first whenever we
         * wish to move to a new tableau in the solution. The star pair is
         * found and added to the basic pairs vector.
         */
        void determine_star_pair();

        /**
         * Returns the matrix of supply-to-demand allocations for the
         * current tableau.
         *
         * @return An integer matrix containing the allocations.
         */
        IntMatrix get_allocations() const;

        /**
         * Returns the basic pairs for the current tableau. The basic pairs
         * will be mostly those pairs that correspond to a non-trivial
         * supply-to-demand allocation.
         *
         * @return A vector containing the current basic pairs.
         */
        std::vector<IntPair> get_basic_pairs() const;

        /**
         * Returns the current transportation cost for the tableau.
         *
         * @return An integer containing the current cost.
         */
        int get_cost() const;

        /**
         * Returns the cycle that was most recently found using the
         * determine_cycle() method.
         *
         * @return The most recent CycleTraversal object for the tableau.
         */
        const CycleTraversal get_cycle() const;

        /**
         * Returns the demands vector for the transportation problem.
         *
         * @return A vector containing the demand values.
         */
        std::vector<int> get_demands() const;

        /**
         * Returns the matrix of link-flow costs for the transportation
         * problem.
         *
         * @return An integer matrix containing the link-flow costs.
         */
        IntMatrix get_link_flow_costs() const;

        /**
         * Returns the star pair that was most recently found using the
         * determine_star_pair() method.
         *
         * @return The most recent star IntPair for the tableau.
         */
        const IntPair get_star_pair() const;

        /**
         * Returns the supplies vector for the transportation problem,
         *
         * @return A vector containing the supply values.
         */
        std::vector<int> get_supplies() const;

        /**
         * Returns the ui variable values for the Dual problem.
         *
         * @return A vector containing the ui values.
         */
        std::vector<int> get_ui_values() const;

        /**
         * Returns the vj variable values for the Dual problem.
         *
         * @return A vector containing the vj values.
         */
        std::vector<int> get_vj_values() const;

        /**
         * Returns true if the current tableau allocations are optimal,
         * and returns false otherwise. This is determined by checking
         * for dual-feasibility for the ui and vj values.
         *
         * @return True if optimal tableau reached, false otherwise.
         */
        bool is_optimal() const;

        /**
         * Moves to the next most optimal tableau for the transportation
         * problem.
         *
         * This method is provided to abstract away the process of actually
         * manipulating the tableau. It does all the work of finding the
         * next star pair, finding the cycle, making the adjustments to
         * the allocations and solving for the next set of ui and vj
         * values -- simply by calling those methods responsible for such
         * tasks.
         *
         * However it does them all at once, which may not be helpful
         * for demonstrative purposes. In such cases the process can still
         * be worked in a step-by-step manner by calling each of the
         * methods manually yourself.
         */
        void next_tableau();

        /**
         * Applies the North-West corner rule to the tableau to find an
         * initial basic solution to the transportation problem, and also
         * finds the first set of ui and vj values.
         *
         * This method should be called once at the start (after the
         * tableau has been instantiated).
         */
        void northwest_corner_rule();

        /**
         * Updates the ui and vj values for the Dual problem according to
         * the current tableau allocations.
         *
         * This method should be called whenever the allocation for the
         * tableau has been adjusted (which happens through each call
         * to the adjust_allocations() method.)
         *
         * Technical note: By convention, we always set the first ui value
         * (ie. ui[0]) to be equal to zero, which allows us to deduce the
         * rest of the ui and vj values in turn.
         */
        void solve_ui_vj();

    };

}

#endif

