/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/**
 * @file main.cpp
 *
 * A program to solve a Transportation Problem in Integer Linear
 * Programming, such as would be found in the field of Operations Research.
 * The program promnpts the user for the supplies, demands and link flow
 * costs to set up the tableau (adding fictitious supplies and demands as
 * necessary to balance the problem). The problem is then solved
 * step-by-step, and each of the tableaux is printed to the screen for
 * reference.
 *
 * NOTE:
 * This program was designed mainly for learning and demonstration purposes,
 * and as such, a minimum of effort has been made towards the efficiency of
 * its components. Application of this program to Transportation Problems
 * with excessively large numbers of supplies and demands is not recommended.
 *
 * @author Russell Edson, <russell.andrew.edson@gmail.com>
 * @date 04/07/2014
 */
#include <string>
#include <iostream>
#include <iomanip>

#include "ancillary.hpp"
#include "cycle_traversal.hpp"
#include "tableau.hpp"

using namespace std;
using namespace transportation_tableaux;

/* Function forward-declarations */
void print_tableau(Tableau& tab);
vector<int> prompt_for_supplies(int supplies_count);
vector<int> prompt_for_demands(int demands_count);
IntMatrix prompt_for_costs(int supplies_count, int demands_count);

/* Named constants */
const int GRID_SQUARE_WIDTH = 10;

/**
 * Main function for the Transportation Problem solver.
 *
 * @param argc Command line argument count. N/A.
 * @param argv Command line arguments. Not used.
 */
int main(int argc, const char* argv[]) {
    /* Prompt for the number of supplies. */
    int num_supplies;
    cout << "Enter the number of supplies: ";
    cin >> num_supplies;

    /* Obtain the supplies vector. */
    vector<int> supplies = prompt_for_supplies(num_supplies);
    cout << endl;

    /* Prompt for the number of demands. */
    int num_demands;
    cout << "Enter the number of demands: ";
    cin >> num_demands;

    /* Get the demands vector. */
    vector<int> demands = prompt_for_demands(num_demands);
    cout << endl;

    /* Prompt for the link flow cost matrix. */
    IntMatrix link_flow_cost
            = prompt_for_costs(num_supplies, num_demands);
    cout << endl;

    //TODO: Add code to balance the transportation problem if necessary.
    //
    //

    /* We balance the Transportation Problem if necessary by adding 
     * fictituous supplies or demands.
     */
    if (sum_elements(supplies) != sum_elements(demands)) {
        cout << "The given Transportation Problem is unbalanced." << endl;
        int difference = sum_elements(supplies) - sum_elements(demands);

        if (difference < 0) {
            cout << "Adding fictitious supplier to balance.." << endl;
            //num_supplies++;
            supplies.push_back(-1*difference);

            /* We add a row of 0s to the link-flow for the supply. */
            link_flow_cost.push_back( std::vector<int>(num_demands, 0));
        }
        else {
            cout << "Adding fictitious demand to balance.." << endl;
            //num_demands++;
            demands.push_back(difference);

            /* We add a column of 0s for the fictitious demand. */
            for (std::vector<int>& column : link_flow_cost) {
                column.push_back(0);
            }
        }
    }

    /* Instantiate the Tableau class used to solve the problem,
     * and perform the North-West corner rule to start with. */
    Tableau tab(link_flow_cost, supplies, demands);
    tab.northwest_corner_rule();

    /* Print the first result tableau. */
    cout << endl;
    cout << "The initial tableau (after the North-West Corner rule):" << endl;
    print_tableau(tab);

    /* Keep printing tableaux until the optimal allocation has been
     * reached.
     */
    while (!tab.is_optimal()) {
        tab.next_tableau();
        cout << "Next tableau:" << endl;
        print_tableau(tab);
    }
    cout << "Optimum cost reached: " << tab.get_cost() << endl;

    return 0;
}

/**
 * Prints the current transport tableau to the screen. The ui and vj values
 * are specified above the tableau, and the current cost is printed below
 * the tableau for easy inspection.
 *
 * @param tab The transportation tableau to be printed.
 */
void print_tableau(Tableau& tab) {
    /* We print a dotted line to visually separate the current tableau
     * from any other tableaus that have been printed previously.
     */
    cout << setfill('-') << setw(5 * GRID_SQUARE_WIDTH) << "" << endl;

    /* Print ui values */
    cout << "Ui: ";
    for (int& ui : tab.get_ui_values()) {
        cout << ui << " ";
    }
    cout << endl;

    /* Print vj values */
    cout << "Vj: ";
    for (int& vj : tab.get_vj_values()) {
        cout << vj << " ";
    }
    cout << endl;

    /* Get the tableau information needed to print the grid. */
    IntMatrix link_flow_cost = tab.get_link_flow_costs();
    IntMatrix allocations = tab.get_allocations();

    /* We determine the horizontal size for the square grid so that
     * everything prints nicely.
     */
    int grid_hsize = allocations[0].size() * GRID_SQUARE_WIDTH + 1;

    /* Print the link flow cost and allocations matrix. */
    for (unsigned int i = 0; i < allocations.size(); i++) {
        cout << "\t" << setfill('-') << setw(grid_hsize) << "" << endl;
        cout << "\t|";
        for (unsigned int j = 0; j < allocations[i].size(); j++) {
            cout << setfill(' ') << setw(GRID_SQUARE_WIDTH - 2)
                 << right << link_flow_cost[i][j] << " |";
        }
        cout << endl << "\t|";
        for (unsigned int j = 0; j < allocations[i].size(); j++) {
            cout << " " << setfill(' ') << setw(GRID_SQUARE_WIDTH - 2)
                 << left << allocations[i][j] << "|";
        }
        cout << endl;
    }

    cout << "\t" << setfill('-') << setw(grid_hsize) << "" << endl;

    /* We print the current grid cost at the bottom of the tableau. */
    cout << "Cost = " << tab.get_cost() << endl;
    cout << endl << endl;
}

/**
 * Prompts the user for each of the supply amounts and constructs
 * the supply vector for the program.
 *
 * @param supplies_count The number of supplies needed.
 * @return An integer vector containing the supply amounts.
 */
vector<int> prompt_for_supplies(int supplies_count) {
    vector<int> supplies(supplies_count);

    cout << "Enter the " << supplies_count << " supplies: ";
    for (unsigned int i = 0; i < supplies.size(); i++) {
        cin >> supplies[i];
    }

    return supplies;
}

/**
 * Prompts the user for each of the demand amounts and constructs
 * the demands vector for the program to use.
 *
 * @param demands_count The number of demands needed.
 * @return An integer vector containing the supply amounts.
 */
vector<int> prompt_for_demands(int demands_count) {
    vector<int> demands(demands_count);

    cout << "Enter the " << demands_count << " demands: ";
    for (unsigned int i = 0; i < demands.size(); i++) {
        cin >> demands[i];
    }

    return demands;
}

/**
 * Prompts the user for each of the values in the link flow cost matrix,
 * as read from left-to-right (ie. across the columns) one row at a time,
 * starting from the top-most row. The matrix (a vector of integer vectors)
 * is returned for the program to use.
 *
 * @param supplies_count The number of supplies for the problem.
 * @param demands_count The number of demands for the problem.
 * @return The link flow cost matrix (vector of vectors).
 */
IntMatrix prompt_for_costs(int supplies_count, int demands_count) {
    /* Construct the link flow cost matrix to accept the values. */
    vector< vector<int> > link_flow_cost;
    link_flow_cost.resize(supplies_count);
    for (unsigned int i = 0; i < link_flow_cost.size(); i++) {
        link_flow_cost[i].resize(demands_count);
    }

    cout << "Enter the link flow costs (as read from left-to-right,\n"
         << "one row at a time starting from the top).\n";
    for (unsigned int i = 0; i < link_flow_cost.size(); i++) {
        for (unsigned int j = 0; j < link_flow_cost[i].size(); j++) {
            cin >> link_flow_cost[i][j];
        }
    }

    return link_flow_cost;
}

