/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include <exception>
#include <iostream>
#include <string>

#include "../src/ancillary.hpp"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE ancillary_testcases
#include <boost/test/unit_test.hpp>

using namespace transportation_tableaux;

/* We test the idempotent functions a certain number of times to make sure
 * that repeated composition doesn't modify the result.
 */
const int IDEMPOTENCY_TEST_COUNT = 10;

/* We test the pure functions a certain number of times to make sure that
 * identical inputs correspond to identical outputs.
 */
const int PURITY_TEST_COUNT = 10;


/* Tests whether the find_adjacent_pairs() function works appropriately
 * when no candidates are provided (we should have no adjacent pairs.)
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__empty_input ) {
    std::vector<IntPair> none = { };
    IntPair check_pair {4,4};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, none);
    BOOST_CHECK( adjacent.empty() );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * a single pair to the left.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__left_single ) {
    std::vector<IntPair> pairs { {0,0}, {1,0}, {2,0} };
    IntPair check_pair {1,1};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {1,0} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * the closest pair to the left when there are multiple to choose from.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__left_multiple ) {
    std::vector<IntPair> pairs { {1,0}, {1,2}, {1,1} };
    IntPair check_pair {1,3};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {1,2} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * a single pair to the right.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__right_single ) {
    std::vector<IntPair> pairs { {0,1}, {1,1}, {2,1} };
    IntPair check_pair {1,0};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {1,1} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * the closest pair to the right when multiple candidates exist.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__right_multiple ) {
    std::vector<IntPair> pairs { {2,2}, {2,7}, {2,1}, {1,1} };
    IntPair check_pair {2,0};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {2,1} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * a single pair above.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__up_single ) {
    std::vector<IntPair> pairs { {0,0}, {0,1}, {0,2} };
    IntPair check_pair {1,1};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {0,1} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * the closest pair above when multiple choices exist.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__up_multiple ) {
    std::vector<IntPair> pairs { {0,2}, {4,2}, {1,2} };
    IntPair check_pair {5,2};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {4,2} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * a single pair below.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__down_single ) {
    std::vector<IntPair> pairs { {1,0}, {1,1}, {1,2} };
    IntPair check_pair {0,1};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {1,1} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly find
 * the closest pair below when multiple choices exist.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__down_multiple ) {
    std::vector<IntPair> pairs { {2,3}, {3,4}, {4,4} };
    IntPair check_pair {0,4};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);

    std::vector<IntPair> should_be { {3,4} };
    BOOST_CHECK( adjacent == should_be );
}

/* Tests whether the find_adjacent_pairs() function can correctly determine
 * that no pairs are adjacent to a given pair.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__no_adjacent ) {
    std::vector<IntPair> pairs { {1,1}, {1,3}, {3,1}, {4,4}, {4,1} };
    IntPair check_pair {2,2};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);
    BOOST_CHECK( adjacent.empty() );
}

/* Tests whether the find_adjacent_pairs() function is idempotent as it
 * should be (the adjacent pairs we found in the first function call should
 * still be adjacent when we apply the function to this output.)
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__idempotency ) {
    std::vector<IntPair> pairs { {1,0}, {1,2}, {1,3}, {2,1} };
    IntPair check_pair {1,1};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);
    for (int i = 0; i < IDEMPOTENCY_TEST_COUNT; i++) {
        std::vector<IntPair> previous = adjacent;
        adjacent = find_adjacent_pairs(check_pair, adjacent);
        BOOST_CHECK( previous == adjacent );
    }
}

/* Tests whether the find_adjacent_pairs() function is pure as it should be
 * (we should get exactly the same output every time we invoke the function
 * to work on the same input.)
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__purity ) {
    std::vector<IntPair> pairs { {0,0}, {1,2}, {2,1}, {2,2}, {2,3} };
    IntPair check_pair {1,1};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);
    for (int i = 0; i < PURITY_TEST_COUNT; i++) {
        BOOST_CHECK( adjacent == find_adjacent_pairs(check_pair, pairs) );
    }
}

/* Tests whether the find_adjacent_pairs() function can correctly
 * determine the adjacent pairs in an arbitrary known case.
 */
BOOST_AUTO_TEST_CASE( FIND_ADJACENT_PAIRS__general_case01 ) {
    std::vector<IntPair> pairs { {0,0}, {0,1}, {1,1}, {1,2}, {2,2} };
    IntPair check_pair {2,0};

    std::vector<IntPair> adjacent = find_adjacent_pairs(check_pair, pairs);
    std::sort(adjacent.begin(), adjacent.end());

    std::vector<IntPair> should_be { {0,0}, {2,2} };
    BOOST_CHECK( adjacent == should_be );
}

//TODO: Add more cases for the find_adjacent_pairs() function.
//


/* Tests whether the find_cycle() function works when an empty vector of
 * pairs is given.
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__empty_input ) {
    std::vector<IntPair> none { };

    std::vector<IntPair> cycle = find_cycle(none);
    BOOST_CHECK( cycle.empty() );
}

/* Tests whether the find_cycle() function can correctly determine when
 * no cycle exists in the given pairs.
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__no_cycle ) {
    std::vector<IntPair> pairs { {3,2}, {1,2}, {3,4} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    BOOST_CHECK( cycle.empty() );
}

/* Tests whether the find_cycle() function can correctly determine that
 * every pair being considered exists on the cycle.
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__only_cycle) {
    std::vector<IntPair> pairs { {0,2}, {0,0}, {3,0}, {3,2} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    std::sort(cycle.begin(), cycle.end());

    std::vector<IntPair> should_be { {0,0}, {0,2}, {3,0}, {3,2} };
    BOOST_CHECK( cycle == should_be );
}

/* Tests whether the find_cycle() function can correctly determine that
 * no redundant pairs exist (ie. once we've pruned to the cycle once,
 * every pair left remaining contributes to the cycle structure.)
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__no_redundant_pairs ) {
    std::vector<IntPair> pairs { {2,0}, {0,1}, {1,0}, {1,1}, {2,1}, {2,2} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    std::sort(cycle.begin(), cycle.end());

    std::vector<IntPair> should_be = { {1,0}, {1,1}, {2,0}, {2,1} };
    BOOST_CHECK( cycle == should_be );
}

/* Tests whether the find_cycle() function can correctly determine that
 * there is exactly one redundant pair and remove it properly.
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__one_redundant_pair ) {
    std::vector<IntPair> pairs { {2,0}, {0,0}, {0,1}, {0,2}, {2,2}, {3,2} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    std::sort(cycle.begin(), cycle.end());

    std::vector<IntPair> should_be = { {0,0}, {0,2}, {2,0}, {2,2} };
    BOOST_CHECK( cycle == should_be );
}

/* Tests whether the find_cycle() function can correctly determine that
 * there are multiple redundant pairs, and remove each of them properly
 * and without error.
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__multiple_redundant_pairs ) {
    std::vector<IntPair> pairs 
            { {0,0}, {0,1}, {0,2}, {1,2}, {2,2}, {3,2}, {3,0} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    std::sort(cycle.begin(), cycle.end());

    std::vector<IntPair> should_be { {0,0}, {0,2}, {3,0}, {3,2} };
    BOOST_CHECK( cycle == should_be );
}

/* Tests whether the find_cycle() function is pure as it should be
 * (we should be pruning down to the cycle in a completely deterministic
 * way, so we should get the same minimal cycle for the same input.)
 */
BOOST_AUTO_TEST_CASE( FIND_CYCLE__purity ) {
    std::vector<IntPair> pairs { {1,1}, {2,0}, {2,1}, {3,0}, {3,1} };

    std::vector<IntPair> cycle = find_cycle(pairs);
    for (int i = 0; i < PURITY_TEST_COUNT; i++) {
        BOOST_CHECK( cycle == find_cycle(pairs) );
    }
}

//TODO: Add more cases for the find_cycle() function.
//


/* Tests whether the remove_pair() function works correctly for
 * trying to remove a pair from an empty vector.
 */
BOOST_AUTO_TEST_CASE( REMOVE_PAIR__empty_input ) {
    std::vector<IntPair> none { };
    IntPair pair_to_remove {1,1};

    remove_pair(pair_to_remove, none);
    BOOST_CHECK( none.empty() );
}

/* Tests whether the remove_pair() function works correctly to
 * remove a pair from the vector when that pair does exist in
 * the vector.
 */
BOOST_AUTO_TEST_CASE( REMOVE_PAIR__existing ) {
    std::vector<IntPair> pairs { {0,0}, {0,1}, {1,0}, {1,1} };
    IntPair pair_to_remove {1,0};

    remove_pair(pair_to_remove, pairs);

    std::vector<IntPair> should_be { {0,0}, {0,1}, {1,1} };
    BOOST_CHECK( pairs == should_be );
}

/* Tests whether the remove_pair() function works correctly to
 * remove a pair from the vector when that pair does not
 * actually exist in the vector (should do nothing.)
 */
BOOST_AUTO_TEST_CASE( REMOVE_PAIR__nonexistent ) {
    std::vector<IntPair> pairs { {0,1}, {2,0}, {3,0} };
    IntPair pair_to_remove {2,1};

    remove_pair(pair_to_remove, pairs);

    std::vector<IntPair> should_be { {0,1}, {2,0}, {3,0} };
    BOOST_CHECK( pairs == should_be );
}

/* Tests whether the remove_pair() function works correctly to
 * remove a pair from the vector when duplicates exist in the
 * vector -- only the first instance should be removed.
 */
BOOST_AUTO_TEST_CASE( REMOVE_PAIR__duplicate ) {
    std::vector<IntPair> pairs { {0,0}, {1,1}, {2,2}, {1,1}, {1,1} };
    IntPair pair_to_remove {1,1};

    remove_pair(pair_to_remove, pairs);

    std::vector<IntPair> should_be { {0,0}, {2,2}, {1,1}, {1,1} };
    BOOST_CHECK( pairs == should_be );
}

//TODO: Add more cases for the remove_pair() function.
//


/* Tests whether the sum_elements() function works correctly for
 * positive elements.
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__positive ) {
    std::vector<int> pos_values { 1, 5, 17, 42, 66, 81, 217 };
    BOOST_CHECK( sum_elements(pos_values) == 429 );
}

/* Tests whether the sum_elements() function works correctly for
 * negative elements.
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__negative ) {
    std::vector<int> neg_values { -4, -57, -100, -202, -9 };
    BOOST_CHECK( sum_elements(neg_values) == -372 );
}

/* Tests whether the sum_elements() function works correctly for
 * duplicate values.
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__duplicates ) {
    std::vector<int> dup_values { 14, 14, 14 };
    BOOST_CHECK( sum_elements(dup_values) == 42 );
}

/* Tests whether the sum_elements() function works correctly for
 * adding a vector containing only zero elements.
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__zeroes ) {
    std::vector<int> zeroes { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    BOOST_CHECK( sum_elements(zeroes) == 0 );
}

/* Tests whether the sum_elements() function works "correctly" for
 * summing up an empty vector (we expect a sum of 0 in this case.)
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__empty_input ) {
    std::vector<int> none { };
    BOOST_CHECK( sum_elements(none) == 0 );
}

/* Tests whether the sum_elements() function works correctly for
 * a case involving positive, negative and zero elements together.
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__mixed ) {
    std::vector<int> mixed { 12, -44, 0, 71, -315, -52, 0, 47, -47 };
    BOOST_CHECK( sum_elements(mixed) == -328 );
}

/* Tests the sum_elements() function for purity (we should get the
 * same answer each time we call the function on the same input.)
 */
BOOST_AUTO_TEST_CASE( SUM_ELEMENTS__purity ) {
    std::vector<int> example { 22, 14, -1, 0, 54, 22 };

    int results[PURITY_TEST_COUNT];
    for (int i = 0; i < PURITY_TEST_COUNT; i++) {
        results[i] = sum_elements(example);
    }

    for (int j = 1; j < PURITY_TEST_COUNT; j++) {
        BOOST_CHECK( results[0] == results[j] );
    }
}

//TODO: Add more cases for the sum_elements() function.
//

