/*
 * Copyright (c) 2013-2014 Russell Edson
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include <exception>
#include <iostream>
#include <string>

#include "../src/ancillary.hpp"
#include "../src/cycle_traversal.hpp"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE cycle_traversal_testcases
#include <boost/test/unit_test.hpp>

using namespace transportation_tableaux;

/* The methods of the class should be pure (ie. have no side effects and
 * return the same answer every time they are called.) We test for this a
 * certain number of times, as defined here.
 */
const int PURITY_TEST_COUNT = 10;

/* For each test case we make sure that the cycle traversal was created as
 * expected (ie. the traversal_order, plus/minus pairs and star_pair should
 * match the input parameters exactly.)
 */
void test_cycle_traversal(  CycleTraversal& cycle,
                            std::vector<IntPair>& traversal_order_shouldbe,
                            std::vector<IntPair>& plus_pairs_shouldbe,
                            std::vector<IntPair>& minus_pairs_shouldbe,
                            IntPair& star_pair_shouldbe ) {

    unsigned int cycle_size = std::distance(cycle.begin(), cycle.end());
    BOOST_CHECK( cycle_size == traversal_order_shouldbe.size() );

    for (unsigned int i = 0; i < traversal_order_shouldbe.size(); i++) {
        IntPair& current_pair = *(cycle.begin()+i);
        BOOST_CHECK( current_pair.first == traversal_order_shouldbe[i].first );

        BOOST_CHECK( current_pair.second == traversal_order_shouldbe[i].second );
    }

    BOOST_CHECK( cycle.get_plus_pairs() == plus_pairs_shouldbe );
    BOOST_CHECK( cycle.get_minus_pairs() == minus_pairs_shouldbe );
    BOOST_CHECK( cycle.get_star_pair() == star_pair_shouldbe );

}

/* Tests whether the CycleTraversal() constructor can deal with an empty
 * cycle (we define its behaviour to simply return the star pair on its
 * own in the traversal. The plus_pairs will contain only the star pair,
 * and the minus_pairs will not contain anything.)
 */
BOOST_AUTO_TEST_CASE( CYCLETRAVERSAL__empty_cycle ) {
    IntPair star_pair {1,1};
    std::vector<IntPair> none { };

    try {
        CycleTraversal cycle(star_pair, none);
        std::vector<IntPair> traversal { {1,1} };
        std::vector<IntPair> plus { {1,1} };
        std::vector<IntPair> minus { };
        test_cycle_traversal(cycle, traversal, plus, minus, star_pair);
    }
    catch(std::exception& ex) {
        BOOST_FAIL( "CycleTraversal instantiation failed: "
                + std::string(ex.what()) );
    }
}

/* Tests whether the CycleTraversal() constructor can deal with a list of
 * pairs that don't form a cycle -- expected behaviour is similar to the
 * empty cycle case: the star pair should be the only pair in the traversal,
 * plus_pairs should contain the star pair only, and minus_pairs should not
 * contain anything.
 */
BOOST_AUTO_TEST_CASE( CYCLETRAVERSAL__no_cycle ) {
    IntPair star_pair {3,4};
    std::vector<IntPair> no_cycle { {1,1}, {2,1}, {1,3} };

    try {
        CycleTraversal cycle(star_pair, no_cycle);
        std::vector<IntPair> traversal { {3,4} };
        std::vector<IntPair> plus { {3,4} };
        std::vector<IntPair> minus { };
        test_cycle_traversal(cycle, traversal, plus, minus, star_pair);
    }
    catch(std::exception& ex) {
        BOOST_FAIL( "CycleTraversal instantiation failed: "
                + std::string(ex.what()) );
    }
}

/* Tests a basic (0,0)-(1,0)-(1,1)-(0,1) cycle case to make sure that the
 * traversal is created as expected.
 */
BOOST_AUTO_TEST_CASE( CYCLETRAVERSAL__basic_cycle ) {
    IntPair star_pair {1,0};
    std::vector<IntPair> basic_cycle { {0,0}, {0,1}, {1,0}, {1,1} };

    try {
        CycleTraversal cycle(star_pair, basic_cycle);
        std::vector<IntPair> traversal { {1,0}, {1,1}, {0,1}, {0,0} };
        std::vector<IntPair> plus { {1,0}, {0,1} };
        std::vector<IntPair> minus { {1,1}, {0,0} };
        test_cycle_traversal(cycle, traversal, plus, minus, star_pair);
    }
    catch(std::exception& ex) {
        BOOST_FAIL( "CycleTraversal instantiation failed: "
                + std::string(ex.what()) );
    }
}
