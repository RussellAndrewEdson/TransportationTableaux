TransportationTableaux
======================

Solves a given Transportation Problem in Operations Research step-by-step! 
Designed for teaching/demonstration purposes.


The source code is written in the C++11 standard, so make sure your compiler
supports it before you try to make/compile!

We also test everything with the boost unit-testing framework, so make sure
that library exists on your system too before you try to compile the test suite.

You can compile the project easily in a Linux/Unix environment using the Makefile (provided your GCC version supports the C++11 standard). Make clean first to ensure that the binaries and object files have been cleared locally.

```
make clean
make bin/test_ancillary
...
make bin/transportation_tableaux
```
