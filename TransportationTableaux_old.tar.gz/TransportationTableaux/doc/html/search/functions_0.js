var searchData=
[
  ['adjust_5fallocations',['adjust_allocations',['../classtransportation__tableaux_1_1Tableau.html#a786f52d63b97fcfaa79777fe7cbf3ac2',1,'transportation_tableaux::Tableau']]]
];
