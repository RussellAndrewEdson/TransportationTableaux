var searchData=
[
  ['tableau',['Tableau',['../classtransportation__tableaux_1_1Tableau.html',1,'transportation_tableaux']]]
];
