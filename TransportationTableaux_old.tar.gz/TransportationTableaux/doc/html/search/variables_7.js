var searchData=
[
  ['plus_5fpairs',['plus_pairs',['../classtransportation__tableaux_1_1CycleTraversal.html#aa0dbd37609546f197d557f3908fef1f0',1,'transportation_tableaux::CycleTraversal']]]
];
