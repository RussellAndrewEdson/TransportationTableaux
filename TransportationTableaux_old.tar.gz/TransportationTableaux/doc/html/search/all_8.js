var searchData=
[
  ['link_5fflow_5fcosts',['link_flow_costs',['../classtransportation__tableaux_1_1Tableau.html#ab0b340d9ece699ab74440be3d99e9a7a',1,'transportation_tableaux::Tableau']]]
];
