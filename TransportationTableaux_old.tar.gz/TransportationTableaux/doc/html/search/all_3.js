var searchData=
[
  ['demands',['demands',['../classtransportation__tableaux_1_1Tableau.html#a106d61287c1b64c8841796cb41eddb22',1,'transportation_tableaux::Tableau']]],
  ['determine_5fcycle',['determine_cycle',['../classtransportation__tableaux_1_1Tableau.html#a3fca4d446c6554ff11822a0498dd80ce',1,'transportation_tableaux::Tableau']]],
  ['determine_5fstar_5fpair',['determine_star_pair',['../classtransportation__tableaux_1_1Tableau.html#a106af94a198d9646d048eb26cb5d8f01',1,'transportation_tableaux::Tableau']]]
];
