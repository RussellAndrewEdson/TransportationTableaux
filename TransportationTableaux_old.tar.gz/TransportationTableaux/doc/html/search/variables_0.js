var searchData=
[
  ['allocations',['allocations',['../classtransportation__tableaux_1_1Tableau.html#ab023f248c4c1f017d1de258addd6e780',1,'transportation_tableaux::Tableau']]]
];
