var searchData=
[
  ['basic_5fpairs',['basic_pairs',['../classtransportation__tableaux_1_1Tableau.html#a80560ae5c40fd7b26e78fb15368c4777',1,'transportation_tableaux::Tableau']]],
  ['begin',['begin',['../classtransportation__tableaux_1_1CycleTraversal.html#a9f6a114d005c31f28e787376fd0ac24f',1,'transportation_tableaux::CycleTraversal::begin()'],['../classtransportation__tableaux_1_1CycleTraversal.html#a0a02ab7f19384e61768fb5f28d5fb4be',1,'transportation_tableaux::CycleTraversal::begin() const ']]]
];
