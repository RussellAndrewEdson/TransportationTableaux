var searchData=
[
  ['vj_5fvalues',['vj_values',['../classtransportation__tableaux_1_1Tableau.html#aa9985a4e127ecefc4f852b44b32b9c09',1,'transportation_tableaux::Tableau']]]
];
