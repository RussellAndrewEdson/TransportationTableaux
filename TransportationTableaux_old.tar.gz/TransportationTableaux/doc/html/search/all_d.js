var searchData=
[
  ['solve_5fui_5fvj',['solve_ui_vj',['../classtransportation__tableaux_1_1Tableau.html#a1b3eba17ff38e6388e2c48979f4764a9',1,'transportation_tableaux::Tableau']]],
  ['star_5fpair',['star_pair',['../classtransportation__tableaux_1_1CycleTraversal.html#a3d3d2f1bc6a8f98f447f61fdb07c72c0',1,'transportation_tableaux::CycleTraversal::star_pair()'],['../classtransportation__tableaux_1_1Tableau.html#ae2492f3f93cb1e8ef4d4fc790e8099a7',1,'transportation_tableaux::Tableau::star_pair()']]],
  ['sum_5felements',['sum_elements',['../namespacetransportation__tableaux.html#a5b0aa59200951855c549fe56801af65a',1,'transportation_tableaux']]],
  ['supplies',['supplies',['../classtransportation__tableaux_1_1Tableau.html#af36176923c9b2e4b85f4766740604031',1,'transportation_tableaux::Tableau']]]
];
