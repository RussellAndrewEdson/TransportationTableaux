var searchData=
[
  ['solve_5fui_5fvj',['solve_ui_vj',['../classtransportation__tableaux_1_1Tableau.html#a1b3eba17ff38e6388e2c48979f4764a9',1,'transportation_tableaux::Tableau']]],
  ['sum_5felements',['sum_elements',['../namespacetransportation__tableaux.html#a5b0aa59200951855c549fe56801af65a',1,'transportation_tableaux']]]
];
