var searchData=
[
  ['intmatrix',['IntMatrix',['../namespacetransportation__tableaux.html#a6bb6373566425be43b19e96631c15fa5',1,'transportation_tableaux']]],
  ['intpair',['IntPair',['../namespacetransportation__tableaux.html#a950e71319322fc5d6123411de5d04c7b',1,'transportation_tableaux']]]
];
