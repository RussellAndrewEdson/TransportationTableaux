var searchData=
[
  ['is_5foptimal',['is_optimal',['../classtransportation__tableaux_1_1Tableau.html#a3e470c17d40607f1079d7b2a7d37d430',1,'transportation_tableaux::Tableau']]]
];
