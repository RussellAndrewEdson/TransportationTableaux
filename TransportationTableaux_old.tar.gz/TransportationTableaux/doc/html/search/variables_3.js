var searchData=
[
  ['demands',['demands',['../classtransportation__tableaux_1_1Tableau.html#a106d61287c1b64c8841796cb41eddb22',1,'transportation_tableaux::Tableau']]]
];
