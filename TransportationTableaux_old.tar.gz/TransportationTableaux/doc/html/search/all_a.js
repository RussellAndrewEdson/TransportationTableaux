var searchData=
[
  ['next_5ftableau',['next_tableau',['../classtransportation__tableaux_1_1Tableau.html#ab58645e2554574d0a466ecf99a537eb8',1,'transportation_tableaux::Tableau']]],
  ['northwest_5fcorner_5frule',['northwest_corner_rule',['../classtransportation__tableaux_1_1Tableau.html#a85509c9bbc05b7cde2062268c2bb6343',1,'transportation_tableaux::Tableau']]]
];
