var searchData=
[
  ['basic_5fpairs',['basic_pairs',['../classtransportation__tableaux_1_1Tableau.html#a80560ae5c40fd7b26e78fb15368c4777',1,'transportation_tableaux::Tableau']]]
];
