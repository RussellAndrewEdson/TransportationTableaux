var searchData=
[
  ['traversal_5forder',['traversal_order',['../classtransportation__tableaux_1_1CycleTraversal.html#a4850c36e4e09547031680966518b9302',1,'transportation_tableaux::CycleTraversal']]]
];
